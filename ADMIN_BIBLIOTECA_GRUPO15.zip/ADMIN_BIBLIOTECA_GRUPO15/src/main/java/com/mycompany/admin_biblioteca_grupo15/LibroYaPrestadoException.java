/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.admin_biblioteca_grupo15;

/**
 *
 * @author wdiazc
 */
public class LibroYaPrestadoException extends Exception {
    public LibroYaPrestadoException (String mensaje){
    super (mensaje);
    }
}
