/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exp_1_s2_grupo15;

/**
 *
 * @author wdiazc
 */
public interface MostrarInformacion {
    void mostrarDatos();
}
